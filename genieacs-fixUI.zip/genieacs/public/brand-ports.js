(function () {
  "use strict";

  var PANEL_ID = "genieacs-brand-ports-panel";

  function onBrandPage() {
    var h = location.hash || "";
    return h.indexOf("admin/logo") !== -1;
  }

  function removePanel() {
    var el = document.getElementById(PANEL_ID);
    if (el) el.remove();
  }

  function findMount() {
    var heads = document.querySelectorAll("h1,h2,h3");
    for (var i = 0; i < heads.length; i++) {
      if (/logo|favicon|brand/i.test(heads[i].textContent || "")) {
        var sec = heads[i].closest("section") || heads[i].parentElement;
        if (sec) return sec;
      }
    }
    var files = document.querySelectorAll('input[type="file"]');
    if (!files.length) return null;
    var a = files[0];
    var b = files[files.length - 1];
    var p = a;
    while (p) {
      if (p.contains && p.contains(b)) return p;
      p = p.parentElement;
    }
    return files[0].parentElement;
  }

  function style() {
    return (
      "#" +
      PANEL_ID +
      "{margin-top:1.75rem;padding:1rem 1.25rem;border:1px solid rgba(255,255,255,.12);border-radius:6px;background:rgba(0,0,0,.25);max-width:520px}" +
      "#" +
      PANEL_ID +
      " h2{margin:0 0 .35rem;font-size:1.1rem;font-weight:600}" +
      "#" +
      PANEL_ID +
      " p{margin:0 0 1rem;opacity:.85;font-size:.9rem}" +
      "#" +
      PANEL_ID +
      " label{display:block;margin:.65rem 0 .2rem;font-size:.85rem}" +
      "#" +
      PANEL_ID +
      " input{width:100%;max-width:16rem;padding:.35rem .5rem;box-sizing:border-box}" +
      "#" +
      PANEL_ID +
      " .row{display:flex;gap:.75rem;flex-wrap:wrap;margin-top:1rem}" +
      "#" +
      PANEL_ID +
      " button{cursor:pointer;padding:.45rem .85rem;border-radius:4px;border:1px solid rgba(255,255,255,.2);background:rgba(255,255,255,.08);color:inherit}" +
      "#" +
      PANEL_ID +
      " button.primary{background:#3b82f6;border-color:#2563eb}" +
      "#" +
      PANEL_ID +
      " button.danger{background:transparent;border-color:#f87171;color:#fca5a5}" +
      "#" +
      PANEL_ID +
      " .msg{margin-top:.75rem;font-size:.85rem;white-space:pre-wrap}"
    );
  }

  function browserPort() {
    var p = location.port;
    if (p) return parseInt(p, 10);
    return location.protocol === "https:" ? 443 : 80;
  }

  function buildUiUrl(newUiPort) {
    return (
      location.protocol +
      "//" +
      location.hostname +
      ":" +
      newUiPort +
      location.pathname +
      location.search +
      location.hash
    );
  }

  function whenNewUiReady(newUiPort, done) {
    var probe = location.protocol + "//" + location.hostname + ":" + newUiPort + "/";
    var n = 0;
    function tick() {
      n++;
      fetch(probe, { method: "GET", credentials: "omit", cache: "no-store" })
        .then(function (r) {
          if (r.ok) done();
          else if (n < 40) setTimeout(tick, 400);
          else done();
        })
        .catch(function () {
          if (n < 40) setTimeout(tick, 400);
          else done();
        });
    }
    setTimeout(tick, 600);
  }

  function injectPanel() {
    if (!onBrandPage()) {
      removePanel();
      return;
    }
    if (document.getElementById(PANEL_ID)) return;

    var mount = findMount();
    if (!mount) return;

    var st = document.createElement("style");
    st.textContent = style();
    document.head.appendChild(st);

    var root = document.createElement("div");
    root.id = PANEL_ID;
    root.innerHTML =
      "<h2>Change server ports</h2>" +
      "<p>Port changes are written to the GenieACS env file and services are restarted. If you change the Web UI port, this page will try to open the same path on the new port once the server is back.</p>" +
      "<label>CWMP port</label><input type=\"number\" data-k=\"cwmp\" min=\"1\" max=\"65535\" />" +
      "<label>NBI port</label><input type=\"number\" data-k=\"nbi\" min=\"1\" max=\"65535\" />" +
      "<label>File server port</label><input type=\"number\" data-k=\"fs\" min=\"1\" max=\"65535\" />" +
      "<label>Web UI port</label><input type=\"number\" data-k=\"ui\" min=\"1\" max=\"65535\" />" +
      "<div class=\"row\">" +
      "<button type=\"button\" class=\"danger\" data-a=\"reset\">Reset ports</button>" +
      "<button type=\"button\" data-a=\"random\" disabled title=\"Not enabled\">Randomize</button>" +
      "<button type=\"button\" class=\"primary\" data-a=\"save\">Save &amp; restart</button>" +
      "</div>" +
      "<div class=\"msg\" data-msg></div>";

    mount.appendChild(root);

    var msg = root.querySelector("[data-msg]");
    function show(t, ok) {
      msg.textContent = t || "";
      msg.style.color = ok ? "#86efac" : "#fca5a5";
    }

    function fill(data) {
      if (!data || !data.ports) return;
      ["cwmp", "nbi", "fs", "ui"].forEach(function (k) {
        var inp = root.querySelector('input[data-k="' + k + '"]');
        if (inp) inp.value = data.ports[k];
      });
    }

    fetch("/api/system/ports", { credentials: "include" })
      .then(function (r) {
        return r.json().then(function (j) {
          if (!r.ok) throw new Error(j.message || j.error || r.statusText);
          return j;
        });
      })
      .then(fill)
      .catch(function (e) {
        show(String(e.message || e), false);
      });

    root.addEventListener("click", function (ev) {
      var a = ev.target && ev.target.getAttribute("data-a");
      if (!a) return;
      if (a === "reset") {
        fill({ ports: { cwmp: 7547, nbi: 7557, fs: 7567, ui: 3000 } });
        show("Defaults loaded. Click Save & restart to apply.", true);
        return;
      }
      if (a === "save") {
        var ports = {};
        ["cwmp", "nbi", "fs", "ui"].forEach(function (k) {
          ports[k] = parseInt(root.querySelector('input[data-k="' + k + '"]').value, 10);
        });
        show("Saving…", true);
        fetch("/api/system/ports", {
          method: "POST",
          credentials: "include",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(ports),
        })
          .then(function (r) {
            return r.json().then(function (j) {
              if (!r.ok) throw new Error(j.message || j.error || r.statusText);
              return j;
            });
          })
          .then(function () {
            var newUi = ports.ui;
            var cur = browserPort();
            if (newUi === cur) {
              show("Restart scheduled (Web UI port unchanged).", true);
              return;
            }
            var target = buildUiUrl(newUi);
            show(
              "Layanan di-restart. Menunggu UI di port " +
                newUi +
                ", lalu mengalihkan otomatis ke:\n" +
                target,
              true
            );
            whenNewUiReady(newUi, function () {
              location.replace(target);
            });
          })
          .catch(function (e) {
            show(String(e.message || e), false);
          });
      }
    });
  }

  function tick() {
    try {
      injectPanel();
    } catch (e) {}
  }

  window.addEventListener("hashchange", tick);
  window.addEventListener("load", tick);
  var mo = new MutationObserver(function () {
    if (onBrandPage()) tick();
  });
  mo.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(tick, 1500);
})();
